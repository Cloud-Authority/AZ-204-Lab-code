﻿
using Azure.Identity;
using Azure.Storage.Blobs;

string tenantId = "";
string clientId = "";
string clientSecret = "";



string blobURI = "https://avenade.blob.core.windows.net/data/veggie.jpg";
string filePath = "D:\\Training\\Accenture\\DEPR\\AZ-204\\Workspace\\day-7\\temp\\temp.jpg";
ClientSecretCredential clientCredential = new ClientSecretCredential(tenantId, clientId, clientSecret);

BlobClient blobClient = new BlobClient(new Uri(blobURI), clientCredential);

await blobClient.DownloadToAsync(filePath);

Console.WriteLine("The blob is downloaded");