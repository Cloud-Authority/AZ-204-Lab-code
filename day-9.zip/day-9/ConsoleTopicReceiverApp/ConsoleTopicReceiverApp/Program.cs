﻿using Azure.Messaging.ServiceBus;
using ConsoleTopicReceiverApp;
using Newtonsoft.Json;
using ConsoleTopicReceiverApp;


string connectionString = "Endpoint=sb://demo1958.servicebus.windows.net/;SharedAccessKeyName=full-access;SharedAccessKey=6ik6+UrNsD28qaAmLS5PJcVzYVqmyg9H5+ASbM50G1M=;EntityPath=orders2";
string topicName = "orders2";
string subscriptionName = "sub1";//change to ConsumerA,ConsumerB,ConsumerC

await ReceiveMessages();

async Task ReceiveMessages()
{
    ServiceBusClient serviceBusClient = new ServiceBusClient(connectionString);
    ServiceBusReceiver serviceBusReceiver = serviceBusClient.CreateReceiver(topicName, subscriptionName,
        new ServiceBusReceiverOptions() { ReceiveMode = ServiceBusReceiveMode.ReceiveAndDelete });

    IAsyncEnumerable<ServiceBusReceivedMessage> messages = serviceBusReceiver.ReceiveMessagesAsync();

    await foreach (ServiceBusReceivedMessage message in messages)
    {

        Order order = JsonConvert.DeserializeObject<Order>(message.Body.ToString());
        Console.WriteLine("Order Id {0}", order.OrderID);
        Console.WriteLine("Quantity {0}", order.Quantity);
        Console.WriteLine("Unit Price {0}", order.UnitPrice);
        Console.WriteLine();
        //await Console.Out.WriteLineAsync();

    }
}
