﻿//sender connection string:
using Azure.Messaging.ServiceBus;

const string connectionString = "Endpoint=sb://avanadesb.servicebus.windows.net/;SharedAccessKeyName=FullAccessKey;SharedAccessKey=kvOea3sOAK61kZAivG72/tRLraysNGogs+ASbDzS4lk=";
const string queueName = "queue1";
ServiceBusClient? client = default;
ServiceBusSender? sender = default;
const int numOfMessages = 3;
client = new ServiceBusClient(connectionString);
sender = client.CreateSender(queueName);

using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();

for (int i = 1; i <= numOfMessages; i++)
{
    if (!messageBatch.TryAddMessage(new ServiceBusMessage($"Message {i}")))
    {
        throw new Exception($"The message {i} is too large to fit in the batch.");
    }
}
try
{
    await sender.SendMessagesAsync(messageBatch);
    Console.WriteLine($"A batch of {numOfMessages} messages has been published to the queue.");
}
finally
{
    await sender.DisposeAsync();
    await client.DisposeAsync();
}