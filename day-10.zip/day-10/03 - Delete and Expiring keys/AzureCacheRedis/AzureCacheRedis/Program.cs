﻿using StackExchange.Redis;

string connectionString = "test1131.redis.cache.windows.net:6380,password=NCP36LVtTdXQRSqNWFxIlTzisPgcH7SncAzCaPt8zss=,ssl=True,abortConnect=False";

ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(connectionString);

SetCacheData();
//GetCacheData();
//DeleteKey("top:3:products");
SetKeyExpiry("top:3:products", new TimeSpan(0, 1, 0));

void SetCacheData()
{
    IDatabase database=redis.GetDatabase();

    database.StringSet("top:3:products", "Mobile, TV, Shirt");

    Console.WriteLine("Cache data set");
}

void GetCacheData()
{
    IDatabase database = redis.GetDatabase();
    if (database.KeyExists("top:3:products"))
        Console.WriteLine(database.StringGet("top:3:products"));
    else
        Console.WriteLine("key does not exist");

}

void DeleteKey(string keyName)
{
    IDatabase database = redis.GetDatabase();
    if (database.KeyExists("top:3:products"))
    {
        database.KeyDelete(keyName);
        Console.WriteLine("Key deleted");
    }
    else
        Console.WriteLine("key does not exist");
}

void SetKeyExpiry(string key,TimeSpan expiry)
{
    IDatabase database = redis.GetDatabase();
    database.KeyExpire(key, expiry);
    Console.WriteLine("Set the key expiry to 1 min");
}