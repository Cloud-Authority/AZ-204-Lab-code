﻿using StackExchange.Redis;

string connectionString = "test1131.redis.cache.windows.net:6380,password=NCP36LVtTdXQRSqNWFxIlTzisPgcH7SncAzCaPt8zss=,ssl=True,abortConnect=False";

ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(connectionString);

SetCacheData();
GetCacheData();

void SetCacheData()
{
    IDatabase database=redis.GetDatabase();

    database.StringSet("top:3:products", "Mobile, TV, Shirt");

    Console.WriteLine("Cache data set");
}

void GetCacheData()
{
    IDatabase database = redis.GetDatabase();
    if (database.KeyExists("top:3:products"))
        Console.WriteLine(database.StringGet("top:3:products"));
    else
        Console.WriteLine("key does not exist");

}